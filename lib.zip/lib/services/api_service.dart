import 'dart:async';
import 'dart:convert';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String _customHostKey = 'api_custom_base_url';
  static String? _cachedBaseUrl;
  static bool? _isDatabaseConnected;

  /// Default candidate hosts based on platform
  static List<String> get _candidateUrls {
    if (kIsWeb) {
      return ['http://127.0.0.1:5000', 'http://localhost:5000'];
    }

    try {
      if (Platform.isAndroid) {
        return [
          'http://10.0.2.2:5000', // Standard Android Emulator
          'http://127.0.0.1:5000', // Port-forwarded or reverse-proxy
          'http://192.168.1.4:5000', // Host Wi-Fi LAN address
          'http://localhost:5000',
        ];
      }
    } catch (_) {}

    return [
      'http://127.0.0.1:5000',
      'http://localhost:5000',
      'http://192.168.1.4:5000',
    ];
  }

  /// Get current working or configured base URL
  static Future<String> getBaseUrl() async {
    if (_cachedBaseUrl != null) return _cachedBaseUrl!;

    final prefs = await SharedPreferences.getInstance();
    final custom = prefs.getString(_customHostKey);
    if (custom != null && custom.trim().isNotEmpty) {
      _cachedBaseUrl = custom.trim();
      return _cachedBaseUrl!;
    }

    // Auto-detect working candidate
    for (final candidate in _candidateUrls) {
      try {
        final res = await http
            .get(Uri.parse('$candidate/api/health'))
            .timeout(const Duration(milliseconds: 1500));
        if (res.statusCode == 200 || res.statusCode == 503) {
          _cachedBaseUrl = candidate;
          _isDatabaseConnected = (res.statusCode == 200);
          return candidate;
        }
      } catch (_) {
        // Try next candidate
      }
    }

    // Fallback default
    if (!kIsWeb) {
      try {
        if (Platform.isAndroid) {
          _cachedBaseUrl = 'http://10.0.2.2:5000';
          return _cachedBaseUrl!;
        }
      } catch (_) {}
    }

    _cachedBaseUrl = 'http://127.0.0.1:5000';
    return _cachedBaseUrl!;
  }

  /// Override the backend URL manually (e.g. for custom Wi-Fi network)
  static Future<void> setCustomBaseUrl(String? url) async {
    final prefs = await SharedPreferences.getInstance();
    if (url == null || url.trim().isEmpty) {
      await prefs.remove(_customHostKey);
      _cachedBaseUrl = null;
    } else {
      String clean = url.trim();
      if (!clean.startsWith('http://') && !clean.startsWith('https://')) {
        clean = 'http://$clean';
      }
      if (clean.endsWith('/')) {
        clean = clean.substring(0, clean.length - 1);
      }
      await prefs.setString(_customHostKey, clean);
      _cachedBaseUrl = clean;
    }
  }

  /// Check connectivity to backend & MongoDB Compass database
  static Future<bool> checkConnection() async {
    try {
      final base = await getBaseUrl();
      final res = await http
          .get(Uri.parse('$base/api/health'))
          .timeout(const Duration(seconds: 3));
      final isOk = (res.statusCode == 200);
      _isDatabaseConnected = isOk;
      return isOk;
    } catch (_) {
      // If cached host failed, invalidate and retry candidates once
      _cachedBaseUrl = null;
      for (final candidate in _candidateUrls) {
        try {
          final res = await http
              .get(Uri.parse('$candidate/api/health'))
              .timeout(const Duration(seconds: 2));
          if (res.statusCode == 200) {
            _cachedBaseUrl = candidate;
            _isDatabaseConnected = true;
            return true;
          }
        } catch (_) {}
      }
      _isDatabaseConnected = false;
      return false;
    }
  }

  static bool? get lastKnownConnectionStatus => _isDatabaseConnected;

  // =========================================================================
  // AUTHENTICATION (MongoDB Users Collection)
  // =========================================================================

  /// Register a new user in MongoDB Compass
  static Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String phone,
    required String password,
  }) async {
    final base = await getBaseUrl();
    final response = await http
        .post(
          Uri.parse('$base/api/register'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'name': name.trim(),
            'email': email.trim().toLowerCase(),
            'phone': phone.trim(),
            'password': password,
          }),
        )
        .timeout(const Duration(seconds: 8));

    final Map<String, dynamic> data = jsonDecode(response.body);
    if (response.statusCode == 201) {
      return {'success': true, 'data': data};
    } else {
      return {
        'success': false,
        'error': data['error'] ?? 'Registration failed with code ${response.statusCode}'
      };
    }
  }

  /// Login and verify credentials against MongoDB Compass
  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    final base = await getBaseUrl();
    final response = await http
        .post(
          Uri.parse('$base/api/login'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'email': email.trim().toLowerCase(),
            'password': password,
          }),
        )
        .timeout(const Duration(seconds: 8));

    final Map<String, dynamic> data = jsonDecode(response.body);
    if (response.statusCode == 200) {
      return {'success': true, 'data': data};
    } else {
      return {
        'success': false,
        'error': data['error'] ?? 'Invalid credentials or user not registered'
      };
    }
  }

  // =========================================================================
  // LAND MEASUREMENTS (MongoDB Lands Collection)
  // =========================================================================

  /// Fetch all saved land measurements from MongoDB Compass for user
  static Future<List<Map<String, dynamic>>> getLands(String email) async {
    try {
      final base = await getBaseUrl();
      final cleanEmail = Uri.encodeComponent(email.trim().toLowerCase());
      final response = await http
          .get(Uri.parse('$base/api/lands/$cleanEmail'))
          .timeout(const Duration(seconds: 6));

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (decoded is List) {
          return decoded.cast<Map<String, dynamic>>();
        }
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  /// Save or update land measurement in MongoDB Compass
  static Future<Map<String, dynamic>> saveLand(Map<String, dynamic> landData) async {
    final base = await getBaseUrl();
    final response = await http
        .post(
          Uri.parse('$base/api/lands'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(landData),
        )
        .timeout(const Duration(seconds: 8));

    final data = jsonDecode(response.body);
    if (response.statusCode == 200 || response.statusCode == 201) {
      return {'success': true, 'data': data};
    } else {
      return {'success': false, 'error': data['error'] ?? 'Failed to save land'};
    }
  }

  /// Delete land measurement from MongoDB Compass
  static Future<bool> deleteLand(String id) async {
    try {
      final base = await getBaseUrl();
      final response = await http
          .delete(Uri.parse('$base/api/lands/$id'))
          .timeout(const Duration(seconds: 6));
      return (response.statusCode == 200);
    } catch (_) {
      return false;
    }
  }
}
